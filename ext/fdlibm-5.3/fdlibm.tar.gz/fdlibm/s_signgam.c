#include "fdlibm.h"
int signgam = 0;
